"""
fix_eprakruti_core.py
=====================
AUTO-FIX SCRIPT for eprakruti_core.py
Fixes all Streamlit (st.session_state) references that cause
NameError when the file runs as a standalone Python API (FastAPI/Flask)
outside of Streamlit.

HOW TO RUN:
    1. Place this file in the SAME folder as eprakruti_core.py
       i.e. D:\\xampp\\htdocs\\eprakruti_ci4_package\\py\\
    2. Open Command Prompt in that folder
    3. Run:  python fix_eprakruti_core.py
    4. Check the output — it will tell you every line it fixed
    5. A backup of the original is saved as eprakruti_core.py.bak

Author  : Dr. Prasanna Kulkarni (Atharva AyurTech Healthcare)
Version : 1.0
"""

import os
import re
import shutil
from datetime import datetime

# ── ANTHROPOMETRIC FUNCTIONS ──────────────────────────────────────────────────

def calc_bmi(weight_kg, height_cm):
    """
    Calculate Body Mass Index (BMI).

    Args:
        weight_kg  : float — body weight in kilograms
        height_cm  : float — height in centimetres

    Returns:
        float : BMI value rounded to 2 decimal places
                Returns None if inputs are invalid.

    Formula : BMI = weight(kg) / height(m)^2
    Ref     : WHO 1995, 2000, 2004; CCRAS PAS 2018 (Apachita/Upachita)
    """
    try:
        weight_kg = float(weight_kg)
        height_cm = float(height_cm)
        if weight_kg <= 0 or height_cm <= 0:
            return None
        height_m = height_cm / 100.0
        bmi = weight_kg / (height_m ** 2)
        return round(bmi, 2)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def calc_whr(waist_cm, hip_cm, gender="Male"):
    """
    Calculate Waist-Hip Ratio (WHR).

    Args:
        waist_cm : float — waist circumference in centimetres
        hip_cm   : float — hip circumference in centimetres
        gender   : str   — "Male" or "Female"

    Returns:
        float : WHR value rounded to 3 decimal places
                Returns None if inputs are invalid.

    Normal ranges (WHO):
        Male   : WHR < 0.90 = normal | >= 0.90 = abdominal obesity
        Female : WHR < 0.85 = normal | >= 0.85 = abdominal obesity

    Ref : WHO 2000; CCRAS PAS 2018 SOP for Apachita/Upachita assessment
    """
    try:
        waist_cm = float(waist_cm)
        hip_cm   = float(hip_cm)
        if waist_cm <= 0 or hip_cm <= 0:
            return None
        whr = waist_cm / hip_cm
        return round(whr, 3)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def calc_bmr(weight_kg, height_cm, age, gender="Male"):
    """
    Calculate Basal Metabolic Rate (BMR) using Mifflin-St Jeor equation.

    Args:
        weight_kg : float — body weight in kilograms
        height_cm : float — height in centimetres
        age       : int   — age in years
        gender    : str   — "Male" or "Female"

    Returns:
        float : BMR in kcal/day, rounded to 1 decimal place
                Returns None if inputs are invalid.

    Formula:
        Male   : BMR = (10 × weight_kg) + (6.25 × height_cm) − (5 × age) + 5
        Female : BMR = (10 × weight_kg) + (6.25 × height_cm) − (5 × age) − 161

    Ref : Mifflin MD et al. 1990; used in RGUHS research project dietary module
    """
    try:
        weight_kg = float(weight_kg)
        height_cm = float(height_cm)
        age       = float(age)
        if weight_kg <= 0 or height_cm <= 0 or age <= 0:
            return None
        if str(gender).strip().lower() in ("female", "f"):
            bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age) - 161
        else:
            bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age) + 5
        return round(bmr, 1)
    except (TypeError, ValueError):
        return None


def get_bmi_category(bmi):
    """
    Return WHO BMI category and Ayurvedic Prakriti implication.

    Args:
        bmi : float — BMI value

    Returns:
        dict with keys:
            category     : WHO category string
            ayur_term    : Sanskrit term
            dosha        : Primary Dosha implication
            vata_score   : int (0-3) additional Vata weight
            kapha_score  : int (0-3) additional Kapha weight
            color        : hex color for UI display

    Ref : CCRAS PAS SOP — Apachita (Vata) / Upachita (Kapha); WHO BMI 2004
    """
    if bmi is None:
        return {
            "category"   : "Unknown",
            "ayur_term"  : "Avijnata",
            "dosha"      : "Neutral",
            "vata_score" : 0,
            "kapha_score": 0,
            "color"      : "#888888"
        }

    if bmi < 16.0:
        return {
            "category"   : "Severe Underweight",
            "ayur_term"  : "Ati-Apachita (Ruksha-Laghu Vata)",
            "dosha"      : "Vata (strong)",
            "vata_score" : 3,
            "kapha_score": 0,
            "color"      : "#c0392b"
        }
    elif bmi < 18.5:
        return {
            "category"   : "Underweight",
            "ayur_term"  : "Apachita (Ruksha-Vata)",
            "dosha"      : "Vata",
            "vata_score" : 2,
            "kapha_score": 0,
            "color"      : "#e67e22"
        }
    elif bmi < 23.0:
        # Using Asian BMI cutoff (23 instead of 25) for Indian population
        return {
            "category"   : "Normal weight",
            "ayur_term"  : "Sama-Deha (Prakriti-Anusar)",
            "dosha"      : "Balanced",
            "vata_score" : 0,
            "kapha_score": 0,
            "color"      : "#27ae60"
        }
    elif bmi < 27.5:
        return {
            "category"   : "Overweight",
            "ayur_term"  : "Upachita (Sandra-Kapha)",
            "dosha"      : "Kapha",
            "vata_score" : 0,
            "kapha_score": 2,
            "color"      : "#f39c12"
        }
    elif bmi < 32.5:
        return {
            "category"   : "Obese Class I",
            "ayur_term"  : "Ati-Upachita (Guru-Kapha)",
            "dosha"      : "Kapha (strong)",
            "vata_score" : 0,
            "kapha_score": 3,
            "color"      : "#e74c3c"
        }
    else:
        return {
            "category"   : "Obese Class II+",
            "ayur_term"  : "Medoroga-Pravritti (Kapha-Medo Dushti)",
            "dosha"      : "Kapha (very strong)",
            "vata_score" : 0,
            "kapha_score": 3,
            "color"      : "#922b21"
        }


def get_whr_status(whr, gender="Male"):
    """
    Return WHR status and abdominal obesity assessment.

    Args:
        whr    : float — WHR value
        gender : str   — "Male" or "Female"

    Returns:
        dict with keys:
            status       : "Normal" or "Abdominal Obesity"
            ayur_term    : Sanskrit interpretation
            dosha        : Dosha implication
            kapha_score  : int (0-2)
    """
    if whr is None:
        return {
            "status"     : "Unknown",
            "ayur_term"  : "Avijnata",
            "dosha"      : "Neutral",
            "kapha_score": 0
        }

    gender_lower = str(gender).strip().lower()
    threshold    = 0.85 if gender_lower in ("female", "f") else 0.90

    if whr < threshold:
        return {
            "status"     : "Normal",
            "ayur_term"  : "Sama Kati-Sphik Pramana",
            "dosha"      : "Balanced",
            "kapha_score": 0
        }
    else:
        return {
            "status"     : "Abdominal Obesity",
            "ayur_term"  : "Kati-Sphik Vriddhi (Medo-Kapha)",
            "dosha"      : "Kapha",
            "kapha_score": 2
        }


def get_anthropometric_summary(weight_kg, height_cm, age,
                               gender="Male",
                               waist_cm=None, hip_cm=None):
    """
    Master anthropometric function — calculates BMI, WHR, BMR
    and returns a complete summary dict for use in Prakriti scoring
    and dietary recommendations.

    Args:
        weight_kg : float — weight in kg
        height_cm : float — height in cm
        age       : int   — age in years
        gender    : str   — "Male" / "Female"
        waist_cm  : float — waist circumference in cm (optional)
        hip_cm    : float — hip circumference in cm (optional)

    Returns:
        dict with all anthropometric values, categories,
        Dosha implications and additional scores.

    Ref : CCRAS PAS 2018 SOP; WHO BMI Standards; Mifflin-St Jeor 1990;
          Charaka Vimana Sthana 8/98 (Apachita/Upachita)
    """
    # Core calculations
    bmi = calc_bmi(weight_kg, height_cm)
    bmr = calc_bmr(weight_kg, height_cm, age, gender)
    whr = calc_whr(waist_cm, hip_cm, gender) if (waist_cm and hip_cm) else None

    # Ayurvedic interpretations
    bmi_info = get_bmi_category(bmi)
    whr_info  = get_whr_status(whr, gender) if whr is not None else None

    # Combined additional Dosha scores from anthropometry
    extra_vata  = bmi_info.get("vata_score",  0)
    extra_kapha = bmi_info.get("kapha_score", 0)
    if whr_info:
        extra_kapha += whr_info.get("kapha_score", 0)

    return {
        # Raw values
        "bmi"               : bmi,
        "bmr"               : bmr,
        "whr"               : whr,
        "weight_kg"         : weight_kg,
        "height_cm"         : height_cm,
        "age"               : age,
        "gender"            : gender,

        # BMI interpretation
        "bmi_category"      : bmi_info["category"],
        "bmi_ayur_term"     : bmi_info["ayur_term"],
        "bmi_dosha"         : bmi_info["dosha"],
        "bmi_color"         : bmi_info["color"],

        # WHR interpretation
        "whr_status"        : whr_info["status"]    if whr_info else "Not measured",
        "whr_ayur_term"     : whr_info["ayur_term"] if whr_info else "N/A",
        "whr_dosha"         : whr_info["dosha"]     if whr_info else "N/A",

        # Additional Dosha scores to add to questionnaire scores
        "extra_vata_score"  : extra_vata,
        "extra_kapha_score" : extra_kapha,

        # Display strings
        "bmi_display"       : f"{bmi} kg/m²" if bmi else "N/A",
        "bmr_display"       : f"{bmr} kcal/day" if bmr else "N/A",
        "whr_display"       : f"{whr}" if whr else "Not measured",
    }


# ── Config ────────────────────────────────────────────────────────────────────
TARGET_FILE  = "eprakruti_core.py"
BACKUP_EXT   = ".bak"
LOG_FILE     = "fix_log.txt"
# ─────────────────────────────────────────────────────────────────────────────


def log(msg, log_lines):
    print(msg)
    log_lines.append(msg)


def fix_file():
    log_lines = []
    log_lines.append(f"Fix run at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log_lines.append(f"Target    : {TARGET_FILE}")
    log_lines.append("=" * 70)

    # ── Check file exists ────────────────────────────────────────────────────
    if not os.path.exists(TARGET_FILE):
        print(f"ERROR: {TARGET_FILE} not found in current directory.")
        print(f"Current directory: {os.getcwd()}")
        print("Place this script in the same folder as eprakruti_core.py and retry.")
        return

    # ── Backup original ──────────────────────────────────────────────────────
    backup_path = TARGET_FILE + BACKUP_EXT
    shutil.copy2(TARGET_FILE, backup_path)
    log(f"✅ Backup saved: {backup_path}", log_lines)
    log("", log_lines)

    # ── Read original ────────────────────────────────────────────────────────
    with open(TARGET_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()

    fixed_lines   = []
    changes       = []
    total_changes = 0

    # ── Replacement patterns ─────────────────────────────────────────────────
    # Each tuple: (regex_pattern, replacement_string, description)
    PATTERNS = [
        # Pattern 1: st.session_state.get("key", default)
        # Replace with just the default value
        (
            r'st\.session_state\.get\(\s*["\'](\w+)["\']\s*,\s*([^)]+)\)',
            r'\2',
            "st.session_state.get(key, default)  →  default"
        ),
        # Pattern 2: st.session_state.get("key")  — no default
        # Replace with None
        (
            r'st\.session_state\.get\(\s*["\'](\w+)["\']\s*\)',
            r'None',
            "st.session_state.get(key)  →  None"
        ),
        # Pattern 3: st.session_state["key"]
        # Replace with None (safe fallback)
        (
            r'st\.session_state\[["\'](\w+)["\']\]',
            r'None',
            'st.session_state["key"]  →  None'
        ),
        # Pattern 4: st.session_state.key  (attribute access)
        # Replace with None
        (
            r'st\.session_state\.([a-zA-Z_]\w*)',
            r'None',
            "st.session_state.attr  →  None"
        ),
    ]

    # ── Process each line ────────────────────────────────────────────────────
    for line_num, line in enumerate(lines, start=1):
        original_line = line
        modified      = False

        # Skip comment lines and docstrings
        stripped = line.lstrip()
        if stripped.startswith("#"):
            fixed_lines.append(line)
            continue

        # Apply each pattern
        for pattern, replacement, desc in PATTERNS:
            if re.search(pattern, line):
                new_line = re.sub(pattern, replacement, line)
                if new_line != line:
                    changes.append({
                        "line"    : line_num,
                        "before"  : original_line.rstrip(),
                        "after"   : new_line.rstrip(),
                        "pattern" : desc
                    })
                    line     = new_line
                    modified = True
                    total_changes += 1

        fixed_lines.append(line)

    # ── Handle streamlit import ──────────────────────────────────────────────
    # Remove "import streamlit as st" if it exists and st is no longer used
    final_lines = []
    import_removed = False
    for line_num, line in enumerate(fixed_lines, start=1):
        stripped = line.strip()
        if stripped in ("import streamlit as st", "import streamlit"):
            # Check if 'st.' still appears anywhere in remaining file
            remaining = "".join(fixed_lines[line_num:])
            if "st." not in remaining and "st " not in remaining:
                changes.append({
                    "line"    : line_num,
                    "before"  : line.rstrip(),
                    "after"   : "# REMOVED: import streamlit as st (not needed in API mode)",
                    "pattern" : "Streamlit import removed"
                })
                final_lines.append(
                    "# REMOVED by fix_eprakruti_core.py: import streamlit as st\n"
                )
                import_removed = True
                total_changes += 1
                continue
        final_lines.append(line)

    # ── Write fixed file ─────────────────────────────────────────────────────
    with open(TARGET_FILE, "w", encoding="utf-8") as f:
        f.writelines(final_lines)

    # ── Report ───────────────────────────────────────────────────────────────
    log(f"Total changes made: {total_changes}", log_lines)
    log("", log_lines)

    if changes:
        log("DETAILED CHANGE LOG:", log_lines)
        log("-" * 70, log_lines)
        for ch in changes:
            log(f"Line {ch['line']:4d} | Pattern : {ch['pattern']}", log_lines)
            log(f"           BEFORE : {ch['before']}", log_lines)
            log(f"           AFTER  : {ch['after']}", log_lines)
            log("", log_lines)
    else:
        log("No st.session_state references found.", log_lines)
        log("The file may already be clean, or patterns were not matched.", log_lines)
        log("Please manually search for 'st.' in eprakruti_core.py", log_lines)

    # ── Verify no st.session_state remains ──────────────────────────────────
    with open(TARGET_FILE, "r", encoding="utf-8") as f:
        content = f.read()

    remaining_issues = []
    for i, line in enumerate(content.split("\n"), start=1):
        if "st.session_state" in line and not line.strip().startswith("#"):
            remaining_issues.append(f"  Line {i}: {line.strip()}")

    log("=" * 70, log_lines)
    if remaining_issues:
        log("⚠️  WARNING: These lines still contain st.session_state:", log_lines)
        log("    (These may be inside strings or complex expressions)", log_lines)
        for issue in remaining_issues:
            log(issue, log_lines)
        log("", log_lines)
        log("Please fix these manually — see INSTRUCTIONS.txt", log_lines)
    else:
        log("✅  CLEAN: No st.session_state references remain.", log_lines)
        log("✅  eprakruti_core.py is ready for API use.", log_lines)

    log("", log_lines)
    log(f"Original backed up at : {backup_path}", log_lines)
    log(f"Fixed file saved at   : {TARGET_FILE}", log_lines)

    # ── Save log ─────────────────────────────────────────────────────────────
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(log_lines))
    log(f"\nFull log saved        : {LOG_FILE}", log_lines)

    print("\n" + "=" * 70)
    print("NEXT STEP: Restart your FastAPI/Flask server and test again.")
    print("If PDF still fails, check fix_log.txt for remaining issues.")
    print("=" * 70)


if __name__ == "__main__":
    fix_file()
